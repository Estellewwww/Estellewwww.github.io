# Hi, I'm Estelle

### Quantitative analytics · Forecasting · Pricing · Portfolio risk

I work in quantitative analytics at **RVI Group**, with responsibilities across the residual-value insurance lifecycle: forecasting, pricing, enrollment, and claims after maturity. My analytical work includes premium and loss analysis, scenario testing, model validation, and production Python/SQL workflows.

I also contribute to periodic market guidebooks and have particular familiarity with vehicle markets in the **UK, Australia, and China**.

I enjoy taking an analytical problem from the initial question through data preparation, modeling, and a tool that people can use to make a decision. Working in a small team has given me a broad view of the insurance process and experience managing several responsibilities at once.

**My toolkit**  
Python · SQL · Statistical modeling · Forecasting · Scenario analysis · Model validation

**What I'm interested in**
- How asset values and portfolio losses respond to changing market conditions
- Building reproducible analyses with clear assumptions and limitations
- Turning quantitative research into practical decision tools

**Background**  
M.S. in Mathematical Finance & Financial Technology, Boston University

---

### Selected project

**Residual Value Scenario Lab**  
An educational Python project exploring vehicle depreciation, terminal-value shocks, and portfolio shortfalls. Includes reproducible synthetic data, scenario charts, and documented modeling assumptions.

*This is an AI-assisted portfolio prototype using synthetic data. It does not contain employer data, proprietary models, or evidence of investment performance.*

Professional experience is described at a general level; employer data, internal model specifications, pricing parameters, client information, and internal results are not shared here.
