# Residual Value Scenario Lab

### How can a change in vehicle values affect a portfolio's shortfall?

A small, reproducible Python lab connecting a stylized vehicle-value curve to portfolio-level loss scenarios. It focuses on transparent assumptions and interpretable outputs.

> **Project status:** AI-assisted educational prototype, prepared for review and extension. All data are synthetic. This is not an RVI model, a calibrated forecasting model, or a claim of personal production research.

![Residual-value scenarios and portfolio shortfall](reports/scenario_overview.png)

## Run it

Python 3.10 or later:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/scenario.py --out reports
```

On Windows, activate with `.venv\Scripts\activate` instead.

The command recreates `reports/synthetic_contracts.csv`, `reports/scenario_summary.json`, and the chart above. The simulation uses Python's built-in random number generator with seed 42 and a fixed draw order; there are no API keys or external data downloads.

## Method

**Vehicle-value curve**

The initial vehicle value is normalized to 100:

`V(t) = 100 × (1 − d)^(t / 12) × [1 + s × min(t / 12, 1)]`

`t` is age in months, `d` is annual depreciation, and `s` is a stylized market shock that ramps in over twelve months. This separates mechanical aging from a hypothetical market scenario; it is not an estimated relationship.

**Synthetic portfolio**

2,000 contracts have terms of 24, 36, or 48 months, annual depreciation uniformly distributed from 10% to 22%, and guarantees between 90% and 110% of the corresponding base value. Terminal values have an additional mean-one lognormal dispersion with log standard deviation 0.08. Every contract has equal notional.

**Shortfall**

`Shortfall_i = max(Guarantee_i − TerminalValue_i × (1 + shock), 0)`

The reported metric is the mean positive shortfall across **all** contracts, including contracts with zero shortfall. It is measured in normalized index points per contract, not dollars or a calibrated expected loss. The portfolio calculation applies the entire shock at the terminal date; the curve shows its earlier ramp-in.

## Reproduced example

| Terminal value shock | Mean shortfall, index points |
| --- | ---: |
| −20% | 12.2057 |
| −10% | 6.5432 |
| 0% | 2.4843 |
| +10% | 0.5905 |

These outputs follow from the stated assumptions. They are not estimates of a real portfolio's risk. A positive base-case shortfall comes from dispersion and guarantees that sometimes exceed realized values; it does not indicate model forecast error.

## What the exercise shows

- A common market shock can affect many contracts at once.
- The positive-part payoff makes shortfall asymmetric.
- A transparent model makes it easier to explain which assumptions drive a result.

## Limitations and next steps

This model has no empirical calibration, out-of-sample test, mileage, vehicle segment, vintage effects, recovery costs, discounting, claim timing, premium income, policy exclusions, or capital requirements. It does not estimate PD/LGD or claim a forecasting accuracy metric. The independent contract dispersion and single common deterministic shock do not constitute a realistic joint risk model.

Before using this as a mature research sample, extend it with legally shareable public data; define a time-based training and evaluation split; compare against a simple depreciation baseline; report error by age and vehicle segment; and investigate scenario sensitivity. Review every formula and be ready to explain it before presenting this repository in an interview.

## Structure

```text
src/scenario.py                  # simulation, scenario calculation, chart generation
reports/synthetic_contracts.csv   # reproducible generated sample
reports/scenario_summary.json    # scenario outputs
reports/scenario_overview.png    # visualization
requirements.txt
```

No employer data, policy details, premium rates, proprietary code, or confidential results are included.
