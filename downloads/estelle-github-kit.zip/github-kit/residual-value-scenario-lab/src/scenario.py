"""Educational residual-value scenario model. All inputs and data are synthetic."""
from pathlib import Path
import argparse
import csv
import json
import math
import random


def residual_value(age_months, annual_depreciation=0.15, shock=0.0):
    """Normalized value; shock ramps in linearly over the first twelve months."""
    if age_months < 0 or not 0 <= annual_depreciation < 1 or not -1 < shock < 1:
        raise ValueError('Invalid age, depreciation, or shock')
    return 100 * (1 - annual_depreciation) ** (age_months / 12) * (1 + shock * min(age_months / 12, 1))


def simulate_contracts(n=2000, seed=42):
    """Simulate end-of-lease values and guarantees; NOT calibrated to real vehicles."""
    rng = random.Random(seed)
    rows = []
    for i in range(n):
        term = rng.choice([24, 36, 48])
        depreciation = rng.uniform(0.10, 0.22)
        base = residual_value(term, depreciation)
        # A stylized contractual guarantee with idiosyncratic vehicle dispersion.
        guarantee = base * rng.uniform(0.9, 1.1)
        noise = math.exp(rng.gauss(-0.5 * 0.08 ** 2, 0.08))
        rows.append({'contract': i + 1, 'term_months': term,
                     'annual_depreciation': depreciation, 'guarantee_index': guarantee,
                     'synthetic_value_index': base * noise})
    return rows


def portfolio_loss(rows, shock):
    """Mean positive shortfall per contract, in normalized index points."""
    return sum(max(r['guarantee_index'] - r['synthetic_value_index'] * (1 + shock), 0)
               for r in rows) / len(rows)


def run(out):
    out.mkdir(parents=True, exist_ok=True)
    rows = simulate_contracts()
    with (out / 'synthetic_contracts.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    shocks = [-0.20, -0.10, 0, 0.10]
    metrics = {f'{s:+.0%}': round(portfolio_loss(rows, s), 4) for s in shocks}
    (out / 'scenario_summary.json').write_text(json.dumps(metrics, indent=2) + '\n')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'axes.spines.top': False,
                         'axes.spines.right': False, 'axes.labelcolor': '#18283b'})
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), facecolor='#f6f5f0')
    for ax in axes:
        ax.set_facecolor('#f6f5f0')
        ax.grid(axis='y', alpha=0.15)
    for shock, label, color in [(0.1, 'Upside +10%', '#548674'), (0, 'Base', '#315bd6'), (-0.2, 'Downside −20%', '#bf6c47')]:
        ages = list(range(61))
        axes[0].plot(ages, [residual_value(a, shock=shock) for a in ages], label=label, color=color, lw=2.3)
    axes[0].set(title='A vehicle-value scenario', xlabel='Vehicle age (months)', ylabel='Normalized value (initial = 100)')
    axes[0].legend(frameon=False)
    axes[1].bar(list(metrics), list(metrics.values()), color=['#bf6c47', '#d5a17d', '#315bd6', '#548674'], width=.55)
    axes[1].set(title='Portfolio shortfall under market shocks', xlabel='Shock to terminal vehicle values', ylabel='Mean shortfall (index points / contract)')
    fig.suptitle('Residual Value Scenario Lab', x=.07, ha='left', fontsize=18, fontweight='bold', color='#18283b')
    fig.text(.07, .01, 'Synthetic data · illustrative assumptions · no real portfolio or model-performance claims', fontsize=9, color='#5b6775')
    fig.tight_layout(rect=[0, .04, 1, .92])
    fig.savefig(out / 'scenario_overview.png', dpi=180)
    plt.close(fig)
    return metrics

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=Path('reports'))
    print(json.dumps(run(parser.parse_args().out), indent=2))
